<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SMS Gateway</title>
</head>
<body>
	<div class="container">
		<form action="<?php echo e(route('sms')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		<input type="submit" value="submit">
		</form>
	</div>
</body>
</html><?php /**PATH C:\Users\sai\Downloads\Compressed\Payment-Gateways-4e63cb03bd4786166848b20a8e4bbd53eedda756\Payment-Gateways-4e63cb03bd4786166848b20a8e4bbd53eedda756\resources\views/create.blade.php ENDPATH**/ ?>