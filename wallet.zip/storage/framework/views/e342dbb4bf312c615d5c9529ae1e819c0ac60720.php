 
 <?php $__env->startSection('results'); ?>
 <h1>Search Results</h1>
 <p><?php echo e($users->total()); ?> result(s) for '<?php echo e(request()->input('search')); ?>' </p>
 <table id="example1" class="table table-bordered table-striped">
 	<thead>
 		<tr>
 			<th>Sr.No</th>
 			<th>Name</th>
 			<th>Email</th>
 		</tr>
 	</thead>
 	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 	<tbody>
 	<tr>
 		<td><?php echo e($loop->index + 1); ?></td>
 		<td> <?php echo e($user->name); ?></td>
 		<td><?php echo e($user->email); ?></td>
 	</tr>
 	 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 	</tbody>
 </table>

 	<br><br>
 	 	 <?php echo e($users->appends(request()->input())->links()); ?>

 	<?php $__env->stopSection(); ?>

<?php echo $__env->make('search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sai\Downloads\Compressed\Payment-Gateways-4e63cb03bd4786166848b20a8e4bbd53eedda756\Payment-Gateways-4e63cb03bd4786166848b20a8e4bbd53eedda756\resources\views/searchresults.blade.php ENDPATH**/ ?>