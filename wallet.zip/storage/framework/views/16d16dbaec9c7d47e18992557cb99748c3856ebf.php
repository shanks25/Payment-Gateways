<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SMS Gateway</title>
</head>
<body>
	<div class="container">
		<form action="<?php echo e(route('sms')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		<input type="submit" value="submit">
		</form>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\wallet\resources\views/create.blade.php ENDPATH**/ ?>