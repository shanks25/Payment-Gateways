<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use OVAC\LaravelHubtelPayment\Facades\HubtelPayment;


class WalletController extends Controller
{
	public function index(Request $request)
	{
 
    try{
     $payment = HubtelPayment::ReceiveMoney()
                ->from('0247440440')                //- The phone number to send the prompt to. 
                ->amount(1.00)                    //- The exact amount value of the transaction
                ->description('Online Purchase')    //- Description of the transaction.
                ->customerName('Ariama Victor')     //- Name of the person making the payment.callback after payment. 
                ->channel('mtn-gh')                 //- The mobile network Channel.configuration
                ->run();                            //- Run the transaction after required data.
               dd($payment);
              }
              catch(Exception $e)
              {
                return $e;
              }
            }

          }